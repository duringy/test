const Koa = require('./koa');

const app1 = new Koa();
const app2 = new Koa();
app1.use((ctx) => {
    console.log('app1: ', ctx);
});

app2.use((ctx) => {
    console.log('app2: ', ctx);
});

app1.listen(3000, () => {
    console.log(`server start http://localhost:3000`);
});

app2.listen(4000, () => {
    console.log(`server start http://localhost:4000`);
});

