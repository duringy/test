const Koa = require('koa');

const app = new Koa();
const sleep = (time) => {
    return new Promise((reslove, reject) => {
        setTimeout(() => {
            reslove();
        }, time);
    })
}

// koa 会将多个中间个进行组合，内部将这三个函数全部包装成 promise. 并且将这三个 Promise 串联起来，内部会使用 Promise 连接起来
app.use(async (ctx, next) => {
    console.log(1);
    next(); // next 表示执行下一个
    console.log(2);
});

app.use(async (ctx, next) => {
    console.log(3);
    next();
    console.log(4);
});

app.use(async (ctx, next) => {
    console.log(5);
    next();
    console.log(6);
});

// 以上的执行的结果是： 1 3 5 6 4 2
/**
 * 第一个执行的结果，表示遇到 next 下一个 执行的顺序结果如下所示
app.use(async (ctx, next) => {
    console.log(1);

    async (ctx, next) => {
        console.log(3);

        async (ctx, next) => {
            console.log(5);
            next();
            console.log(6);
        }();

        console.log(4);
    }();

    console.log(2);
});
 */

app.listen(3000, () => {
    console.log(`server start http://localhost:3000`);
});