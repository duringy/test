// const Koa = require('koa');
const { defaultMaxListeners } = require('./koa/lib/application');
const Koa = require('./koa/lib/application'); // 自己的

// 通过 new 的方式创建一个应用
const app = new Koa(); // => const server = createServer(() => {});  //  以前的时候，里面是需要通过一个回调来判断处理

// 以前 使用 http 模块，需要通过判断 req.url 来进行对应的处理
/**
 * 为什么 koa 出现，原因在于 req 和 res 他的功能非常弱 res,.end({}), 增强 req 和 res， koa 给自己生成了两个对象，request 另一个中 response => ctx
 * 
 * 有自己的中间件机制
 * 
 * 错误处理
 */
/*
 app.use(async (ctx) => {
    // throw new Error('error');
    ctx.body = 'Hello world'; // 响应的结果
});
 */

app.use((ctx) => {
    // res.end('hello world!'); // 响应的结果
    // console.log(ctx.req.url); // 原生的
    // console.log(ctx.request.req.url); // koa 上自己封装的 request 上是有 req属性的,这个地方在 request 上增加 req 属性的目的是，在 request 对象中可以通过 this 获取到 req


    // console.log(ctx.request.query); // koa 封装的
    // console.log(ctx.query);

    // ctx.body = 'Hello'; // 它不等价于 res.end(), 也不等价于 res.write
    // ctx.response.body = 'Hello';
    // ctx.response.body = 'World';
    // ctx.body = 'World';
    ctx.body = {
        name: 'lishi'
    }
    console.log(ctx.body);

    
    

});


app.listen(3000, () => {
    console.log(`server start http://localhost:3000`);
}); // => server.listen

app.on('error', (error) => {
    console.log('error: ',error);
})